package com.help;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.Keep;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by 王灼洲 on 2018/7/22
 */
@Keep
public class SensorsDataAPI {
    private final String TAG = this.getClass().getSimpleName();
    public static final String SDK_VERSION = "1.0.0";
    private static SensorsDataAPI INSTANCE;
    private static final Object mLock = new Object();
    private static Map<String, Object> mDeviceInfo;
    private String mDeviceId;

    private Activity mCurrentAct;
    @Keep
    @SuppressWarnings("UnusedReturnValue")
    public static SensorsDataAPI init(Application application) {
        synchronized (mLock) {
            if (null == INSTANCE) {
                INSTANCE = new SensorsDataAPI(application);
            }
            return INSTANCE;
        }
    }

    @Keep
    public static SensorsDataAPI getInstance() {
        return INSTANCE;
    }

    private SensorsDataAPI(Application application) {
        mDeviceId = SensorsDataPrivate.getAndroidID(application.getApplicationContext());
        mDeviceInfo = SensorsDataPrivate.getDeviceInfo(application.getApplicationContext());
    }

    public void setCurrentAct(Activity act){
        mCurrentAct = act;
    }

    /**
     * Track 事件
     *
     * @param eventName  String 事件名称
     * @param properties JSONObject 事件属性
     */
    @Keep
    public void track(@NonNull final String eventName, @Nullable JSONObject properties) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("event", eventName);
            jsonObject.put("device_id", mDeviceId);

            JSONObject sendProperties = new JSONObject(mDeviceInfo);

            if (properties != null) {
                SensorsDataPrivate.mergeJSONObject(properties, sendProperties);
            }
            String element_id = "null_id";
            if(sendProperties.has("$element_id")){
                element_id = sendProperties.getString("$element_id");
            }
            String element_type = sendProperties.getString("$element_type");
            String element_content = "no_content";
            if(!element_type.equals("SeekBar")){
                  element_content =  sendProperties.getString("$element_content");
            }
            String elementPath = sendProperties.getString("$activity")+"_"+element_type
                    +"_"+element_id+"_"+element_content;
// TODO: 2019/5/16  seek bar  without content
            // TODO: 2019/5/16
            if(!eventKey.containsKey(elementPath)) {
                showDialog(elementPath);
            }
            sendProperties.put("$eventPath",eventKey.get(elementPath));
                jsonObject.put("properties", sendProperties);
            jsonObject.put("time", System.currentTimeMillis());

            Log.i(TAG, SensorsDataPrivate.formatJson(jsonObject.toString()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    HashMap<String,String> eventKey = new HashMap<>();
private int i = 0;
    private void showDialog(final String iconId) {
        Context context = mCurrentAct;

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("标题"+iconId);
        builder.setMessage("请输入事件id");
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                eventKey.put(iconId,"flow_play"+i);
                i ++;
            }
        });

        AlertDialog dialog = builder.create();

        dialog.show();
    }

}
