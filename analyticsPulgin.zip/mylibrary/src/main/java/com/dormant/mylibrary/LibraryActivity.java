package com.dormant.mylibrary;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.view.View;
import android.widget.Toast;


@SuppressWarnings("Convert2Lambda")
public class LibraryActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
setContentView( R.layout.library_main);

        initButton();
       }


    /**
     * 普通 setOnClickListener
     */
    private void initButton() {
        AppCompatButton button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ///还可缓解
                showToast("普通");
                //hi 就不积跬步
            }
        });

     }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }


}
